/*! goyabpd 16-09-2014 */
function testMobile() {
    return Modernizr.touch;
}

function update() {
    requestAnimFrame(update);
    var tempRation = window.innerHeight / windowHeight, ratio = tempRation < window.innerWidth / windowWidth ? tempRation : window.innerWidth / windowWidth;
    windowWidthVar = windowWidth * ratio, windowHeightVar = windowHeight * ratio, renderer.view.style.width = windowWidthVar + "px", 
    renderer.view.style.height = windowHeightVar + "px", app.update(), renderer.render(app.stage);
}

var SmartObject = Class.extend({
    init: function() {
        MicroEvent.mixin(this);
    },
    show: function() {},
    hide: function() {},
    build: function() {},
    destroy: function() {}
}), SmartSocket = Class.extend({
    init: function() {
        MicroEvent.mixin(this);
    },
    build: function() {},
    writeObj: function(obj) {
        this.trigger(SmartSocket.WRITE_OBJ, obj);
    },
    readSocketList: function(obj) {
        this.trigger(SmartSocket.READ_SOCKET_SNAPSHOT, obj);
    },
    readObj: function(obj) {
        this.trigger(SmartSocket.READ_OBJ, obj);
    },
    readLast: function(obj) {
        this.trigger(SmartSocket.READ_LAST, obj);
    },
    setReadCallback: function(callback) {
        this.readCallback = callback;
    },
    socketError: function() {
        this.trigger(SmartSocket.SOCKET_ERROR, obj);
    },
    setObj: function(obj) {
        this.trigger(SmartSocket.SET_OBJ, obj);
    },
    updateObj: function(obj) {
        this.trigger(SmartSocket.UPDATE_OBJ, obj);
    },
    destroy: function() {}
});

SmartSocket.UPDATE_OBJ = "updateObj", SmartSocket.READ_OBJ = "readObj", SmartSocket.READ_SOCKET_SNAPSHOT = "readSocketSnapshot", 
SmartSocket.READ_LAST = "readLast", SmartSocket.WRITE_OBJ = "writeObj", SmartSocket.SET_OBJ = "setObj", 
SmartSocket.SOCKET_ERROR = "socketError";

var Application = AbstractApplication.extend({
    init: function(firebaseURL) {
        this._super(windowWidth, windowHeight), this.stage.setBackgroundColor(16777215), 
        this.stage.removeChild(this.loadText), this.isMobile = testMobile(), this.appContainer = document.getElementById("rect"), 
        this.id = parseInt(1e11 * Math.random()), this.socket = new FirebaseSocket(firebaseURL + 12221), 
        this.socket.build(), this.socket.bind(SmartSocket.READ_OBJ, this.readObj), this.socket.bind(SmartSocket.WRITE_OBJ, this.writeObj), 
        this.socket.bind(SmartSocket.SET_OBJ, this.setObj);
    },
    readlast: function(obj) {
        console.log("readlast", obj);
    },
    readSnapshot: function(obj) {
        console.log("readSnapshot", obj);
    },
    readObj: function(obj) {
        console.log("readObj", obj.socket);
    },
    writeObj: function(obj) {
        console.log("writeObj", obj);
    },
    setObj: function(obj) {
        console.log("setObj", obj);
    },
    show: function() {},
    hide: function() {},
    build: function() {
        var self = this;
        if (this.isMobile) {
            this.socket.updateObj({
                userMobile: {
                    isMobile: this.isMobile,
                    id: this.id
                }
            });
            var touchActions = [ "auto", "pan-y", "pan-x", "pan-x pan-y", "none" ];
            Hammer.each(touchActions, function(touchAction) {
                var el = renderer.view, mc = new Hammer(el, {
                    touchAction: touchAction
                });
                mc.get("pan").set({
                    direction: Hammer.DIRECTION_ALL
                }), mc.get("pinch").set({
                    enable: !0
                }), mc.on("pan swipe pinch tap doubletap press", function(ev) {
                    self.socket.updateObj({
                        socket: {
                            message: {
                                pos: ev.center
                            },
                            type: ev.type,
                            id: self.id
                        }
                    });
                });
            });
        } else this.socket.updateObj({
            userDesktop: {
                isMobile: this.isMobile,
                id: this.id
            }
        });
    },
    destroy: function() {}
}), MobileApp = SmartObject.extend({
    init: function() {
        this._super();
    },
    show: function() {},
    hide: function() {},
    build: function() {},
    destroy: function() {}
}), FirebaseSocket = SmartSocket.extend({
    init: function(url) {
        this._super(), this.dataRef = new Firebase(url), this.dataRef.limit(1);
    },
    build: function() {
        var self = this;
        this.lastMessagesQuery = this.dataRef.endAt().limit(2), this.lastMessagesQuery.on("child_added", function(snapshot) {
            self.readLast(snapshot.val());
        }, function(errorObject) {
            self.socketError(errorObject);
        }), this.dataRef.on("child_added", function(snapshot) {
            self.readSocketList(snapshot.val());
        }, function(errorObject) {
            self.socketError(errorObject);
        }), this.dataRef.on("value", function(data) {
            self.readObj(data.val());
        }, function(errorObject) {
            self.socketError(errorObject);
        });
    },
    writeObj: function(obj) {
        this._super(obj), this.dataRef.push(obj);
    },
    setObj: function(obj) {
        this._super(obj), this.dataRef.set(obj);
    },
    updateObj: function(obj) {
        this._super(obj), this.dataRef.update(obj);
    },
    destroy: function() {}
}), windowWidth = 20, windowHeight = 20, windowWidth = 960, windowHeight = 640, renderer, windowWidthVar = window.innerWidth, windowHeightVar = window.innerHeight, renderer = PIXI.autoDetectRenderer(windowWidth, windowHeight), app = new Application("https://jefframos.firebaseio.com/");

app.build(), app.show();

var initialize = function() {
    PIXI.BaseTexture.SCALE_MODE = 0, document.body.appendChild(renderer.view), requestAnimFrame(update);
};

!function() {
    var App = {
        init: function() {
            initialize();
        }
    };
    $(App.init);
}();